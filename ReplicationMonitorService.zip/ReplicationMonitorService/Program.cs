using Npgsql;

// Content root = folder of the exe, so the service finds wwwroot/appsettings when started by Windows
var builder = WebApplication.CreateBuilder(new WebApplicationOptions { Args = args, ContentRootPath = AppContext.BaseDirectory });
builder.Host.UseWindowsService(o => o.ServiceName = "ReplicationMonitor");
builder.Services.AddSingleton<ReplicationMonitor>();
builder.Services.AddHostedService(sp => sp.GetRequiredService<ReplicationMonitor>());

var app = builder.Build();
app.UseDefaultFiles();
app.UseStaticFiles();

app.MapGet("/api/replication/state", (ReplicationMonitor m) => Results.Json(m.GetState()));
app.MapPost("/api/replication/log/clear", (ReplicationMonitor m) => { m.ClearLog(); return Results.Ok(); });

app.Run();

// ======================= Monitor =======================
public class ReplicationMonitor : BackgroundService
{
    private readonly string _primaryCs, _standbyCs;
    private readonly int _intervalSec;
    private readonly long _lagWarnBytes;
    private readonly object _lock = new();

    private readonly List<LogEntry> _log = new();
    private readonly List<HistoryPoint> _history = new();
    private int _logId = 0;
    private int _pollCount = 0;
    private readonly DateTime _startedAt = DateTime.Now;

    private PrimaryInfo _primary = new();
    private StandbyInfo _standby = new();
    private bool _isWorking;
    private DateTime _stateSince = DateTime.Now;
    private DateTime _checkedAt = DateTime.Now;

    // previous values for change detection
    private bool? _prevWorking, _prevPrimaryOk, _prevStandbyOk, _prevPaused, _prevLagHigh;
    private string? _prevStream;

    public ReplicationMonitor(IConfiguration cfg)
    {
        _primaryCs = cfg.GetConnectionString("Primary")!;
        _standbyCs = cfg.GetConnectionString("Standby")!;
        _intervalSec = Math.Max(1, cfg.GetValue("Monitor:IntervalSeconds", 2));
        _lagWarnBytes = cfg.GetValue("Monitor:LagWarnBytes", 16L * 1024 * 1024);
        AddLog("INFO", $"Monitor started (poll every {_intervalSec}s, lag warning at {Fmt(_lagWarnBytes)})");
    }

    protected override async Task ExecuteAsync(CancellationToken ct)
    {
        while (!ct.IsCancellationRequested)
        {
            try { await PollOnce(); } catch (Exception ex) { AddLog("ERROR", "Monitor error: " + ex.Message); }
            await Task.Delay(TimeSpan.FromSeconds(_intervalSec), ct);
        }
    }

    private async Task PollOnce()
    {
        var p = new PrimaryInfo();
        var s = new StandbyInfo();

        // ---------- Primary ----------
        try
        {
            await using var con = new NpgsqlConnection(_primaryCs);
            await con.OpenAsync();
            p.Reachable = true;

            await using (var cmd = new NpgsqlCommand(@"
                SELECT client_addr::text, application_name, state, sync_state,
                       sent_lsn::text, write_lsn::text, flush_lsn::text, replay_lsn::text,
                       COALESCE(pg_wal_lsn_diff(pg_current_wal_lsn(), replay_lsn),0)::bigint,
                       COALESCE(EXTRACT(EPOCH FROM replay_lag)*1000,0)::float8,
                       pg_current_wal_lsn()::text
                FROM pg_stat_replication ORDER BY state LIMIT 1", con))
            await using (var r = await cmd.ExecuteReaderAsync())
            {
                if (await r.ReadAsync())
                {
                    p.ClientAddr = Str(r, 0); p.AppName = Str(r, 1);
                    p.StreamState = Str(r, 2); p.SyncState = Str(r, 3);
                    p.SentLsn = Str(r, 4); p.WriteLsn = Str(r, 5);
                    p.FlushLsn = Str(r, 6); p.ReplayLsn = Str(r, 7);
                    p.LagBytes = r.GetInt64(8); p.ReplayLagMs = r.GetDouble(9);
                    p.CurrentLsn = Str(r, 10);
                }
                else p.StreamState = "no standby connected";
            }

            await using (var cmd = new NpgsqlCommand(
                "SELECT slot_name, active, COALESCE(restart_lsn::text,'-') FROM pg_replication_slots", con))
            await using (var r = await cmd.ExecuteReaderAsync())
                while (await r.ReadAsync())
                    p.Slots.Add(new SlotInfo { Name = r.GetString(0), Active = r.GetBoolean(1), RestartLsn = r.GetString(2) });
        }
        catch (Exception ex) { p.Error = ex.Message; }

        // ---------- Standby ----------
        try
        {
            await using var con = new NpgsqlConnection(_standbyCs);
            await con.OpenAsync();
            s.Reachable = true;
            await using var cmd = new NpgsqlCommand(@"
                SELECT pg_is_in_recovery(),
                       (SELECT status FROM pg_stat_wal_receiver LIMIT 1),
                       pg_last_wal_receive_lsn()::text, pg_last_wal_replay_lsn()::text,
                       COALESCE(EXTRACT(EPOCH FROM (now() - pg_last_xact_replay_timestamp()))*1000,0)::float8,
                       pg_is_wal_replay_paused()", con);
            await using var r = await cmd.ExecuteReaderAsync();
            if (await r.ReadAsync())
            {
                s.InRecovery = r.GetBoolean(0);
                s.WalReceiverStatus = r.IsDBNull(1) ? "not running" : r.GetString(1);
                s.ReceiveLsn = Str(r, 2); s.ReplayLsn = Str(r, 3);
                s.ReplayDelayMs = r.GetDouble(4); s.Paused = r.GetBoolean(5);
            }
        }
        catch (Exception ex) { s.Error = ex.Message; }

        bool working = p.Reachable && s.Reachable && p.StreamState == "streaming"
                       && s.InRecovery && s.WalReceiverStatus == "streaming" && !s.Paused;

        lock (_lock)
        {
            _pollCount++;
            _primary = p; _standby = s; _isWorking = working; _checkedAt = DateTime.Now;
            _history.Add(new HistoryPoint { Time = _checkedAt.ToString("HH:mm:ss"), LagBytes = p.LagBytes, LagMs = p.ReplayLagMs, Working = working });
            if (_history.Count > 90) _history.RemoveAt(0);
            DetectChanges(p, s, working);
        }
    }

    private void DetectChanges(PrimaryInfo p, StandbyInfo s, bool working)
    {
        if (_prevPrimaryOk != p.Reachable)
        {
            if (p.Reachable) AddLog(_prevPrimaryOk == null ? "INFO" : "SUCCESS", "Primary connection OK");
            else AddLog("ERROR", "Primary unreachable: " + p.Error);
            _prevPrimaryOk = p.Reachable;
        }
        if (_prevStandbyOk != s.Reachable)
        {
            if (s.Reachable) AddLog(_prevStandbyOk == null ? "INFO" : "SUCCESS", "Standby connection OK");
            else AddLog("ERROR", "Standby unreachable: " + s.Error);
            _prevStandbyOk = s.Reachable;
        }
        if (p.Reachable && _prevStream != p.StreamState)
        {
            var lvl = p.StreamState == "streaming" ? "SUCCESS" : "WARN";
            AddLog(lvl, _prevStream == null ? $"Stream state: {p.StreamState}" : $"Stream state changed: {_prevStream} → {p.StreamState}");
            _prevStream = p.StreamState;
        }
        if (s.Reachable && _prevPaused != s.Paused)
        {
            if (s.Paused) AddLog("WARN", "WAL replay is PAUSED on standby");
            else if (_prevPaused == true) AddLog("SUCCESS", "WAL replay resumed on standby");
            _prevPaused = s.Paused;
        }
        bool lagHigh = p.LagBytes > _lagWarnBytes;
        if (_prevLagHigh != lagHigh)
        {
            if (lagHigh) AddLog("WARN", $"Replication lag high: {Fmt(p.LagBytes)}");
            else if (_prevLagHigh == true) AddLog("INFO", $"Replication lag back to normal ({Fmt(p.LagBytes)})");
            _prevLagHigh = lagHigh;
        }
        if (_prevWorking != working)
        {
            if (working) AddLog("SUCCESS", _prevWorking == null ? "Replication is WORKING" : "Replication RECOVERED - streaming again");
            else AddLog("ERROR", "Replication is NOT working");
            _prevWorking = working;
            _stateSince = DateTime.Now;
        }
        if (_pollCount % Math.Max(1, 30 / _intervalSec) == 0 && working)
            AddLog("INFO", $"Heartbeat: streaming, lag {Fmt(p.LagBytes)}, replay lag {p.ReplayLagMs:F0} ms, LSN {p.ReplayLsn}");
    }

    public void ClearLog() { lock (_lock) { _log.Clear(); AddLog("INFO", "Log cleared"); } }

    private void AddLog(string level, string msg)
    {
        lock (_lock)
        {
            var e = new LogEntry { Id = ++_logId, Time = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), Level = level, Message = msg };
            _log.Add(e);
            if (_log.Count > 300) _log.RemoveAt(0);
            try   // also keep a daily log file next to the exe: Logs\replication-yyyyMMdd.log
            {
                var dir = Path.Combine(AppContext.BaseDirectory, "Logs");
                Directory.CreateDirectory(dir);
                File.AppendAllText(Path.Combine(dir, $"replication-{DateTime.Now:yyyyMMdd}.log"),
                                   $"{e.Time} [{level}] {msg}{Environment.NewLine}");
            }
            catch { /* never let logging break monitoring */ }
        }
    }

    public object GetState()
    {
        lock (_lock)
            return new
            {
                isWorking = _isWorking,
                checkedAt = _checkedAt,
                startedAt = _startedAt,
                stateSince = _stateSince,
                intervalSeconds = _intervalSec,
                lagWarnBytes = _lagWarnBytes,
                primary = _primary,
                standby = _standby,
                history = _history.ToList(),
                log = _log.ToList()
            };
    }

    private static string Str(NpgsqlDataReader r, int i) => r.IsDBNull(i) ? "-" : r.GetString(i);
    private static string Fmt(long b) => b < 1024 ? $"{b} B" : b < 1048576 ? $"{b / 1024.0:F1} KB" : $"{b / 1048576.0:F1} MB";
}

// ======================= Models =======================
public class PrimaryInfo
{
    public bool Reachable { get; set; }
    public string? Error { get; set; }
    public string ClientAddr { get; set; } = "-";
    public string AppName { get; set; } = "-";
    public string StreamState { get; set; } = "-";
    public string SyncState { get; set; } = "-";
    public string CurrentLsn { get; set; } = "-";
    public string SentLsn { get; set; } = "-";
    public string WriteLsn { get; set; } = "-";
    public string FlushLsn { get; set; } = "-";
    public string ReplayLsn { get; set; } = "-";
    public long LagBytes { get; set; }
    public double ReplayLagMs { get; set; }
    public List<SlotInfo> Slots { get; set; } = new();
}
public class StandbyInfo
{
    public bool Reachable { get; set; }
    public string? Error { get; set; }
    public bool InRecovery { get; set; }
    public string WalReceiverStatus { get; set; } = "-";
    public string ReceiveLsn { get; set; } = "-";
    public string ReplayLsn { get; set; } = "-";
    public double ReplayDelayMs { get; set; }
    public bool Paused { get; set; }
}
public class SlotInfo { public string Name { get; set; } = ""; public bool Active { get; set; } public string RestartLsn { get; set; } = "-"; }
public class HistoryPoint { public string Time { get; set; } = ""; public long LagBytes { get; set; } public double LagMs { get; set; } public bool Working { get; set; } }
public class LogEntry { public int Id { get; set; } public string Time { get; set; } = ""; public string Level { get; set; } = "INFO"; public string Message { get; set; } = ""; }
