ReplicationMonitorService  -  PostgreSQL replication monitor (.NET 8 Windows Service + web dashboard)
==================================================================================================

FOLDER
  ReplicationMonitor.csproj, Program.cs   service source
  wwwroot\index.html                      dashboard UI
  appsettings.json                        settings (copied into publish\ on build)
  1_Build.bat                             builds into publish\ (needs .NET 8 SDK + internet once for NuGet)
  2_Install_Service.bat                   installs + starts Windows service "ReplicationMonitor" (Run as Administrator)
  3_Uninstall_Service.bat                 stops + removes the service
  Run_Console.bat                         test run without installing
  Open_Dashboard.bat                      opens http://localhost:5050

STEPS
  1. Run 1_Build.bat                      -> creates publish\ (self-contained, no .NET needed on target PC)
  2. Edit publish\appsettings.json        -> set Primary and Standby connection strings
  3. Run 2_Install_Service.bat as Administrator
  4. Open http://SERVER-IP:5050

DATABASE USER (run once on the PRIMARY and on the STANDBY)
  GRANT pg_monitor TO monitor;

SETTINGS (appsettings.json)
  Urls                     listening address/port (default http://0.0.0.0:5050)
  Monitor:IntervalSeconds  poll interval (default 2)
  Monitor:LagWarnBytes     lag warning level in bytes (default 16777216 = 16 MB)
  After changing settings:  sc stop ReplicationMonitor  &  sc start ReplicationMonitor

LOGS
  Shown live on the dashboard and written daily to publish\Logs\replication-YYYYMMDD.log

IMPORTANT
  Always open the dashboard through the service address (http://SERVER:5050).
  Opening wwwroot\index.html by double-click shows "Monitor service not reachable".
