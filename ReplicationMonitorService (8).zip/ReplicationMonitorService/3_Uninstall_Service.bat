@echo off
net session >nul 2>&1
if errorlevel 1 (
  echo Please run this file as Administrator.
  pause & exit /b 1
)
sc stop ReplicationMonitor >nul 2>&1
timeout /t 3 >nul
sc delete ReplicationMonitor
netsh advfirewall firewall delete rule name="ReplicationMonitor 5050" >nul 2>&1
echo Service removed.
pause
