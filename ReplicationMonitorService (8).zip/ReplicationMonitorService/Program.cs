using System.Reflection;
using System.Runtime.InteropServices;
using Npgsql;

// Content root = folder of the exe, so the service finds wwwroot/appsettings when started by Windows
var builder = WebApplication.CreateBuilder(new WebApplicationOptions { Args = args, ContentRootPath = AppContext.BaseDirectory });
builder.Host.UseWindowsService(o => o.ServiceName = "ReplicationMonitor");
builder.Services.AddSingleton<ReplicationMonitor>();
builder.Services.AddHostedService(sp => sp.GetRequiredService<ReplicationMonitor>());
builder.Services.AddSingleton<LogicalMonitor>();
builder.Services.AddHostedService(sp => sp.GetRequiredService<LogicalMonitor>());

var app = builder.Build();
app.UseDefaultFiles();
app.UseStaticFiles();

app.MapGet("/api/replication/state", (ReplicationMonitor m) => Results.Json(m.GetState()));
app.MapPost("/api/replication/log/clear", (ReplicationMonitor m) => { m.ClearLog(); return Results.Ok(); });

app.MapGet("/api/replication/version", (IWebHostEnvironment env) =>
{
    var asm = typeof(ReplicationMonitor).Assembly;
    var svc = (asm.GetCustomAttribute<AssemblyInformationalVersionAttribute>()?.InformationalVersion ?? "1.0.0").Split('+')[0];
    string built = "-";
    try { built = File.GetLastWriteTime(Environment.ProcessPath ?? asm.Location).ToString("yyyy-MM-dd HH:mm:ss"); } catch { }
    string portal = "-", portalBuilt = "-";
    try
    {
        var f = Path.Combine(env.WebRootPath ?? Path.Combine(AppContext.BaseDirectory, "wwwroot"), "portal-version.json");
        using var doc = System.Text.Json.JsonDocument.Parse(File.ReadAllText(f));
        portal = doc.RootElement.GetProperty("version").GetString() ?? "-";
        portalBuilt = doc.RootElement.GetProperty("built").GetString() ?? "-";
    }
    catch { }
    return Results.Json(new
    {
        service = svc, serviceBuilt = built, portal, portalBuilt,
        runtime = RuntimeInformation.FrameworkDescription, os = RuntimeInformation.OSDescription, machine = Environment.MachineName
    });
});
app.MapGet("/api/logical/state", (LogicalMonitor m) => Results.Json(m.GetState()));
app.MapPost("/api/logical/count", async (LogicalMonitor m, string schema, string table) => Results.Json(await m.CountRows(schema, table)));
app.MapGet("/api/replication/config", (ReplicationMonitor m) => Results.Json(m.GetConfig()));
app.MapPost("/api/replication/test", async (ReplicationMonitor m) => Results.Json(await m.TestConnections()));

app.Run();

// ======================= Monitor =======================
public class ReplicationMonitor : BackgroundService
{
    private readonly string _primaryCs, _standbyCs;
    private readonly string _primaryHost, _standbyHost;
    private readonly int _intervalSec;
    private readonly long _lagWarnBytes;
    private readonly object _lock = new();

    private readonly List<LogEntry> _log = new();
    private readonly List<HistoryPoint> _history = new();
    private int _logId = 0;
    private int _pollCount = 0;
    private readonly DateTime _startedAt = DateTime.Now;

    private PrimaryInfo _primary = new();
    private StandbyInfo _standby = new();
    private bool _isWorking;
    private DateTime _stateSince = DateTime.Now;
    private int _n = 0;
    private Dictionary<string, long> _primaryDbs = new(), _standbyDbs = new();
    private readonly List<OutageInfo> _outages = new();
    private int _outageSeq = 0;
    // primary-only details (work even when the standby is down)
    private long _pxact = -1, _plsn = -1; private DateTime _pxT, _plsnT;
    private int _walFiles; private long _walBytes;
    private string _archMode = "-"; private long _archOk, _archFail; private DateTime? _archLast;
    private List<SettingInfo> _settingsCache = new();
    private DateTime _checkedAt = DateTime.Now;

    // previous values for change detection
    private bool? _prevWorking, _prevPrimaryOk, _prevStandbyOk, _prevPaused, _prevLagHigh;
    private string? _prevStream;

    public ReplicationMonitor(IConfiguration cfg)
    {
        _primaryCs = cfg.GetConnectionString("Primary")!;
        _standbyCs = cfg.GetConnectionString("Standby")!;
        var pb = new NpgsqlConnectionStringBuilder(_primaryCs); var sb = new NpgsqlConnectionStringBuilder(_standbyCs);
        _primaryHost = $"{pb.Host}:{pb.Port}"; _standbyHost = $"{sb.Host}:{sb.Port}";
        _intervalSec = Math.Max(1, cfg.GetValue("Monitor:IntervalSeconds", 2));
        _lagWarnBytes = cfg.GetValue("Monitor:LagWarnBytes", 16L * 1024 * 1024);
        AddLog("INFO", $"Monitor started (poll every {_intervalSec}s, lag warning at {Fmt(_lagWarnBytes)})");
    }

    protected override async Task ExecuteAsync(CancellationToken ct)
    {
        while (!ct.IsCancellationRequested)
        {
            try { await PollOnce(); } catch (Exception ex) { AddLog("ERROR", "Monitor error: " + ex.Message); }
            await Task.Delay(TimeSpan.FromSeconds(_intervalSec), ct);
        }
    }

    private async Task PollOnce()
    {
        var p = new PrimaryInfo();
        var s = new StandbyInfo();
        bool refreshDbs = (_n++ % 10 == 0);   // database sizes refreshed every 10th poll

        // ---------- Primary ----------
        try
        {
            await using var con = new NpgsqlConnection(_primaryCs);
            await con.OpenAsync();
            p.Reachable = true;

            await using (var cmd = new NpgsqlCommand(@"
                SELECT client_addr::text, application_name, state, sync_state,
                       sent_lsn::text, write_lsn::text, flush_lsn::text, replay_lsn::text,
                       COALESCE(pg_wal_lsn_diff(pg_current_wal_lsn(), replay_lsn),0)::bigint,
                       COALESCE(EXTRACT(EPOCH FROM replay_lag)*1000,0)::float8,
                       pg_current_wal_lsn()::text
                FROM pg_stat_replication ORDER BY state LIMIT 1", con))
            await using (var r = await cmd.ExecuteReaderAsync())
            {
                if (await r.ReadAsync())
                {
                    p.ClientAddr = Str(r, 0); p.AppName = Str(r, 1);
                    p.StreamState = Str(r, 2); p.SyncState = Str(r, 3);
                    p.SentLsn = Str(r, 4); p.WriteLsn = Str(r, 5);
                    p.FlushLsn = Str(r, 6); p.ReplayLsn = Str(r, 7);
                    p.LagBytes = r.GetInt64(8); p.ReplayLagMs = r.GetDouble(9);
                    p.CurrentLsn = Str(r, 10);
                }
                else p.StreamState = "no standby connected";
            }

            await using (var cmd = new NpgsqlCommand(
                "SELECT slot_name, active, COALESCE(restart_lsn::text,'-'), COALESCE(pg_wal_lsn_diff(pg_current_wal_lsn(), restart_lsn),0)::bigint FROM pg_replication_slots", con))
            await using (var r = await cmd.ExecuteReaderAsync())
                while (await r.ReadAsync())
                    p.Slots.Add(new SlotInfo { Name = r.GetString(0), Active = r.GetBoolean(1), RestartLsn = r.GetString(2), RetainedBytes = r.GetInt64(3) });

            try
            {
                var (v, st, tot, act) = await ReadInfo(con);
                p.Version = v; p.StartedAt = st; p.ConnTotal = tot; p.ConnActive = act;
                if (refreshDbs) _primaryDbs = await ReadDbs(con);
            }
            catch { /* extra info is optional */ }

            try
            {
                p.Detail = await ReadPrimaryDetail(con, p, refreshDbs);
                if (p.CurrentLsn == "-" && p.Detail.CurrentLsn != "-") p.CurrentLsn = p.Detail.CurrentLsn;
            }
            catch { /* primary details are optional */ }
        }
        catch (Exception ex) { p.Error = ex.Message; }

        // ---------- Standby ----------
        try
        {
            await using var con = new NpgsqlConnection(_standbyCs);
            await con.OpenAsync();
            s.Reachable = true;
            await using var cmd = new NpgsqlCommand(@"
                SELECT pg_is_in_recovery(),
                       (SELECT status FROM pg_stat_wal_receiver LIMIT 1),
                       pg_last_wal_receive_lsn()::text, pg_last_wal_replay_lsn()::text,
                       COALESCE(EXTRACT(EPOCH FROM (now() - pg_last_xact_replay_timestamp()))*1000,0)::float8,
                       pg_is_wal_replay_paused()", con);
            await using var r = await cmd.ExecuteReaderAsync();
            if (await r.ReadAsync())
            {
                s.InRecovery = r.GetBoolean(0);
                s.WalReceiverStatus = r.IsDBNull(1) ? "not running" : r.GetString(1);
                s.ReceiveLsn = Str(r, 2); s.ReplayLsn = Str(r, 3);
                s.ReplayDelayMs = r.GetDouble(4); s.Paused = r.GetBoolean(5);
            }
            await r.CloseAsync();
            try
            {
                var (v, st, tot, act) = await ReadInfo(con);
                s.Version = v; s.StartedAt = st; s.ConnTotal = tot; s.ConnActive = act;
                if (refreshDbs) _standbyDbs = await ReadDbs(con);
            }
            catch { /* extra info is optional */ }
        }
        catch (Exception ex) { s.Error = ex.Message; }

        bool working = p.Reachable && s.Reachable && p.StreamState == "streaming"
                       && s.InRecovery && s.WalReceiverStatus == "streaming" && !s.Paused;

        lock (_lock)
        {
            _pollCount++;
            _primary = p; _standby = s; _isWorking = working; _checkedAt = DateTime.Now;
            _history.Add(new HistoryPoint { Time = _checkedAt.ToString("HH:mm:ss"), LagBytes = p.LagBytes, LagMs = p.ReplayLagMs, Working = working, Tps = p.Detail?.Tps ?? 0, Conns = p.ConnTotal, WalRate = p.Detail?.WalRate ?? 0 });
            if (_history.Count > 300) _history.RemoveAt(0);
            DetectChanges(p, s, working);
        }
    }

    private void DetectChanges(PrimaryInfo p, StandbyInfo s, bool working)
    {
        if (_prevPrimaryOk != p.Reachable)
        {
            if (p.Reachable) AddLog(_prevPrimaryOk == null ? "INFO" : "SUCCESS", "Primary connection OK");
            else AddLog("ERROR", "Primary unreachable: " + p.Error);
            _prevPrimaryOk = p.Reachable;
        }
        if (_prevStandbyOk != s.Reachable)
        {
            if (s.Reachable) AddLog(_prevStandbyOk == null ? "INFO" : "SUCCESS", "Standby connection OK");
            else AddLog("ERROR", "Standby unreachable: " + s.Error);
            _prevStandbyOk = s.Reachable;
        }
        if (p.Reachable && _prevStream != p.StreamState)
        {
            var lvl = p.StreamState == "streaming" ? "SUCCESS" : "WARN";
            AddLog(lvl, _prevStream == null ? $"Stream state: {p.StreamState}" : $"Stream state changed: {_prevStream} → {p.StreamState}");
            _prevStream = p.StreamState;
        }
        if (s.Reachable && _prevPaused != s.Paused)
        {
            if (s.Paused) AddLog("WARN", "WAL replay is PAUSED on standby");
            else if (_prevPaused == true) AddLog("SUCCESS", "WAL replay resumed on standby");
            _prevPaused = s.Paused;
        }
        bool lagHigh = p.LagBytes > _lagWarnBytes;
        if (_prevLagHigh != lagHigh)
        {
            if (lagHigh) AddLog("WARN", $"Replication lag high: {Fmt(p.LagBytes)}");
            else if (_prevLagHigh == true) AddLog("INFO", $"Replication lag back to normal ({Fmt(p.LagBytes)})");
            _prevLagHigh = lagHigh;
        }
        if (_prevWorking != working)
        {
            if (working) AddLog("SUCCESS", _prevWorking == null ? "Replication is WORKING" : "Replication RECOVERED - streaming again");
            else AddLog("ERROR", "Replication is NOT working");
            _prevWorking = working;
            _stateSince = DateTime.Now;
            TrackOutage(working, p, s);
        }
        if (_pollCount % Math.Max(1, 30 / _intervalSec) == 0 && working)
            AddLog("INFO", $"Heartbeat: streaming, lag {Fmt(p.LagBytes)}, replay lag {p.ReplayLagMs:F0} ms, LSN {p.ReplayLsn}");
    }

    public void LogEvent(string level, string msg) => AddLog(level, msg);

    public void ClearLog() { lock (_lock) { _log.Clear(); AddLog("INFO", "Log cleared"); } }

    private void AddLog(string level, string msg)
    {
        lock (_lock)
        {
            var e = new LogEntry { Id = ++_logId, Time = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), Level = level, Message = msg };
            _log.Add(e);
            if (_log.Count > 300) _log.RemoveAt(0);
            try   // also keep a daily log file next to the exe: Logs\replication-yyyyMMdd.log
            {
                var dir = Path.Combine(AppContext.BaseDirectory, "Logs");
                Directory.CreateDirectory(dir);
                File.AppendAllText(Path.Combine(dir, $"replication-{DateTime.Now:yyyyMMdd}.log"),
                                   $"{e.Time} [{level}] {msg}{Environment.NewLine}");
            }
            catch { /* never let logging break monitoring */ }
        }
    }

    public object GetState()
    {
        lock (_lock)
            return new
            {
                isWorking = _isWorking,
                checkedAt = _checkedAt,
                startedAt = _startedAt,
                stateSince = _stateSince,
                primaryHost = _primaryHost,
                standbyHost = _standbyHost,
                intervalSeconds = _intervalSec,
                lagWarnBytes = _lagWarnBytes,
                primary = _primary,
                standby = _standby,
                history = _history.ToList(),
                outages = _outages.ToList(),
                databases = _primaryDbs.Keys.Union(_standbyDbs.Keys).OrderBy(k => k).Select(k => new
                {
                    name = k,
                    primaryBytes = _primaryDbs.GetValueOrDefault(k, -1L),
                    standbyBytes = _standbyDbs.GetValueOrDefault(k, -1L)
                }).ToList(),
                log = _log.ToList()
            };
    }

    // ---------- outages ----------
    private void TrackOutage(bool working, PrimaryInfo p, StandbyInfo s)
    {
        if (!working)
        {
            _outages.Add(new OutageInfo { Id = ++_outageSeq, Start = DateTime.Now, Reason = Reason(p, s) });
            if (_outages.Count > 200) _outages.RemoveAt(0);
            return;
        }
        var o = _outages.LastOrDefault(x => x.End == null);
        if (o == null) return;
        o.End = DateTime.Now;
        o.DurationSec = (o.End.Value - o.Start).TotalSeconds;
        try
        {
            var dir = Path.Combine(AppContext.BaseDirectory, "Logs");
            Directory.CreateDirectory(dir);
            File.AppendAllText(Path.Combine(dir, "outages.csv"),
                $"{o.Start:yyyy-MM-dd HH:mm:ss},{o.End:yyyy-MM-dd HH:mm:ss},{o.DurationSec:F0},\"{o.Reason.Replace("\"", "'")}\"{Environment.NewLine}");
        }
        catch { }
    }

    private static string Reason(PrimaryInfo p, StandbyInfo s) =>
        !p.Reachable ? "Primary unreachable" + (p.Error != null ? ": " + p.Error : "") :
        !s.Reachable ? "Standby unreachable" + (s.Error != null ? ": " + s.Error : "") :
        p.StreamState != "streaming" ? "Stream state: " + p.StreamState :
        s.Paused ? "WAL replay paused on standby" :
        !s.InRecovery ? "Standby not in recovery mode" : "WAL receiver: " + s.WalReceiverStatus;

    // ---------- primary-only details ----------
    private async Task<PrimaryDetail> ReadPrimaryDetail(NpgsqlConnection con, PrimaryInfo p, bool slow)
    {
        var d = new PrimaryDetail();
        async Task Q(string sql, Func<NpgsqlDataReader, Task> read)
        {
            try { await using var c = new NpgsqlCommand(sql, con); await using var r = await c.ExecuteReaderAsync(); await read(r); }
            catch { /* optional metric - ignore (e.g. missing permission) */ }
        }

        await Q("SELECT pg_is_in_recovery(), current_setting('max_connections')::int", async r =>
        { if (await r.ReadAsync()) { d.InRecovery = r.GetBoolean(0); d.MaxConnections = r.GetInt32(1); } });

        if (!d.InRecovery)
            await Q("SELECT pg_current_wal_lsn()::text, pg_wal_lsn_diff(pg_current_wal_lsn(), '0/0')::bigint", async r =>
            {
                if (!await r.ReadAsync()) return;
                d.CurrentLsn = r.GetString(0); long cur = r.GetInt64(1); var now = DateTime.Now;
                if (_plsn >= 0 && (now - _plsnT).TotalSeconds > 0.5) d.WalRate = Math.Max(0, (cur - _plsn) / (now - _plsnT).TotalSeconds);
                _plsn = cur; _plsnT = now;
            });

        await Q(@"SELECT count(*) FILTER (WHERE state='active')::int, count(*) FILTER (WHERE state='idle')::int,
                         count(*) FILTER (WHERE state='idle in transaction')::int, count(*) FILTER (WHERE wait_event_type='Lock')::int
                  FROM pg_stat_activity WHERE backend_type='client backend'", async r =>
        { if (await r.ReadAsync()) { d.ConnActive = r.GetInt32(0); d.ConnIdle = r.GetInt32(1); d.ConnIdleInTx = r.GetInt32(2); d.ConnLockWait = r.GetInt32(3); } });

        await Q(@"SELECT COALESCE(sum(xact_commit+xact_rollback),0)::bigint, COALESCE(sum(blks_hit),0)::bigint, COALESCE(sum(blks_read),0)::bigint,
                         COALESCE(sum(deadlocks),0)::bigint, COALESCE(sum(temp_files),0)::bigint FROM pg_stat_database", async r =>
        {
            if (!await r.ReadAsync()) return;
            long x = r.GetInt64(0), hit = r.GetInt64(1), rd = r.GetInt64(2); var now = DateTime.Now;
            if (_pxact >= 0 && (now - _pxT).TotalSeconds > 0.5) d.Tps = Math.Max(0, (x - _pxact) / (now - _pxT).TotalSeconds);
            _pxact = x; _pxT = now;
            d.CacheHitPct = hit + rd > 0 ? 100.0 * hit / (hit + rd) : 100;
            d.Deadlocks = r.GetInt64(3); d.TempFiles = r.GetInt64(4);
        });

        if (slow)
        {
            await Q("SELECT count(*)::int, COALESCE(sum(size),0)::bigint FROM pg_ls_waldir()", async r =>
            { if (await r.ReadAsync()) { _walFiles = r.GetInt32(0); _walBytes = r.GetInt64(1); } });
            await Q("SELECT current_setting('archive_mode'), archived_count, failed_count, last_archived_time FROM pg_stat_archiver", async r =>
            { if (await r.ReadAsync()) { _archMode = r.GetString(0); _archOk = r.GetInt64(1); _archFail = r.GetInt64(2); _archLast = r.IsDBNull(3) ? null : r.GetDateTime(3); } });
        }
        if (slow || _settingsCache.Count == 0)
            await Q(@"SELECT name, setting, COALESCE(unit,'') FROM pg_settings WHERE name IN
                      ('wal_level','max_wal_senders','max_replication_slots','wal_keep_size','wal_keep_segments','synchronous_standby_names','archive_mode','max_connections','listen_addresses','hot_standby')
                      ORDER BY name", async r =>
            {
                var l = new List<SettingInfo>();
                while (await r.ReadAsync()) l.Add(new SettingInfo { Name = r.GetString(0), Value = r.GetString(1), Unit = r.GetString(2) });
                if (l.Count > 0) _settingsCache = l;
            });
        d.WalFiles = _walFiles; d.WalDirBytes = _walBytes; d.ArchiveMode = _archMode; d.Archived = _archOk; d.ArchiveFailed = _archFail; d.LastArchived = _archLast; d.Settings = _settingsCache;

        await Q(@"SELECT COALESCE(client_addr::text,'-'), COALESCE(application_name,''), COALESCE(state,'-'), COALESCE(sync_state,'-'),
                         COALESCE(pg_wal_lsn_diff(pg_current_wal_lsn(), replay_lsn),0)::bigint, COALESCE(EXTRACT(EPOCH FROM replay_lag)*1000,0)::float8, backend_start
                  FROM pg_stat_replication ORDER BY client_addr", async r =>
        {
            while (await r.ReadAsync())
                d.Clients.Add(new ClientInfo { Addr = r.GetString(0), App = r.GetString(1), State = r.GetString(2), Sync = r.GetString(3),
                    LagBytes = r.GetInt64(4), ReplayLagMs = r.GetDouble(5), Since = r.IsDBNull(6) ? null : r.GetDateTime(6) });
        });

        await Q(@"SELECT pid, COALESCE(usename,''), COALESCE(datname,''), COALESCE(application_name,''), COALESCE(state,''),
                         COALESCE(EXTRACT(EPOCH FROM (now() - query_start)),0)::float8, left(regexp_replace(COALESCE(query,''), '\s+', ' ', 'g'), 100)
                  FROM pg_stat_activity
                  WHERE backend_type='client backend' AND pid <> pg_backend_pid() AND state IS DISTINCT FROM 'idle'
                  ORDER BY query_start NULLS LAST LIMIT 8", async r =>
        {
            while (await r.ReadAsync())
                d.Queries.Add(new QueryInfo { Pid = r.GetInt32(0), User = r.GetString(1), Db = r.GetString(2), App = r.GetString(3), State = r.GetString(4), Seconds = r.GetDouble(5), Text = r.GetString(6) });
        });
        return d;
    }

    // ---------- extra info helpers ----------
    private static async Task<(string, DateTime, int, int)> ReadInfo(NpgsqlConnection con)
    {
        await using var cmd = new NpgsqlCommand(@"SELECT current_setting('server_version'), pg_postmaster_start_time(),
            (SELECT count(*) FROM pg_stat_activity WHERE backend_type='client backend'),
            (SELECT count(*) FROM pg_stat_activity WHERE backend_type='client backend' AND state='active')", con);
        await using var r = await cmd.ExecuteReaderAsync();
        await r.ReadAsync();
        return (r.GetString(0), r.GetDateTime(1), (int)r.GetInt64(2), (int)r.GetInt64(3));
    }

    private static async Task<Dictionary<string, long>> ReadDbs(NpgsqlConnection con)
    {
        var d = new Dictionary<string, long>();
        await using var cmd = new NpgsqlCommand("SELECT datname, pg_database_size(datname) FROM pg_database WHERE NOT datistemplate ORDER BY 1", con);
        await using var r = await cmd.ExecuteReaderAsync();
        while (await r.ReadAsync()) d[r.GetString(0)] = r.GetInt64(1);
        return d;
    }

    // ---------- settings page ----------
    public object GetConfig()
    {
        object One(string cs) { var b = new NpgsqlConnectionStringBuilder(cs); return new { host = b.Host, port = b.Port, database = b.Database, user = b.Username }; }
        return new { primary = One(_primaryCs), standby = One(_standbyCs), intervalSeconds = _intervalSec, lagWarnBytes = _lagWarnBytes, startedAt = _startedAt };
    }

    public async Task<object> TestConnections()
    {
        async Task<object> T(string cs)
        {
            var sw = System.Diagnostics.Stopwatch.StartNew();
            try
            {
                await using var c = new NpgsqlConnection(cs);
                await c.OpenAsync();
                await using var cmd = new NpgsqlCommand("SELECT 1", c);
                await cmd.ExecuteScalarAsync();
                return new { ok = true, ms = sw.ElapsedMilliseconds, error = (string?)null };
            }
            catch (Exception ex) { return new { ok = false, ms = sw.ElapsedMilliseconds, error = (string?)ex.Message }; }
        }
        return new { primary = await T(_primaryCs), standby = await T(_standbyCs) };
    }

    private static string Str(NpgsqlDataReader r, int i) => r.IsDBNull(i) ? "-" : r.GetString(i);
    private static string Fmt(long b) => b < 1024 ? $"{b} B" : b < 1048576 ? $"{b / 1024.0:F1} KB" : $"{b / 1048576.0:F1} MB";
}

// ======================= Models =======================
public class PrimaryInfo
{
    public bool Reachable { get; set; }
    public string? Error { get; set; }
    public string ClientAddr { get; set; } = "-";
    public string AppName { get; set; } = "-";
    public string StreamState { get; set; } = "-";
    public string SyncState { get; set; } = "-";
    public string CurrentLsn { get; set; } = "-";
    public string SentLsn { get; set; } = "-";
    public string WriteLsn { get; set; } = "-";
    public string FlushLsn { get; set; } = "-";
    public string ReplayLsn { get; set; } = "-";
    public long LagBytes { get; set; }
    public double ReplayLagMs { get; set; }
    public List<SlotInfo> Slots { get; set; } = new();
    public PrimaryDetail? Detail { get; set; }
    public string Version { get; set; } = "-";
    public DateTime? StartedAt { get; set; }
    public int ConnTotal { get; set; }
    public int ConnActive { get; set; }
}
public class StandbyInfo
{
    public bool Reachable { get; set; }
    public string? Error { get; set; }
    public bool InRecovery { get; set; }
    public string WalReceiverStatus { get; set; } = "-";
    public string ReceiveLsn { get; set; } = "-";
    public string ReplayLsn { get; set; } = "-";
    public double ReplayDelayMs { get; set; }
    public bool Paused { get; set; }
    public string Version { get; set; } = "-";
    public DateTime? StartedAt { get; set; }
    public int ConnTotal { get; set; }
    public int ConnActive { get; set; }
}
public class SlotInfo { public string Name { get; set; } = ""; public bool Active { get; set; } public string RestartLsn { get; set; } = "-"; public long RetainedBytes { get; set; } }
public class HistoryPoint { public string Time { get; set; } = ""; public long LagBytes { get; set; } public double LagMs { get; set; } public bool Working { get; set; } public double Tps { get; set; } public int Conns { get; set; } public double WalRate { get; set; } }
public class LogEntry { public int Id { get; set; } public string Time { get; set; } = ""; public string Level { get; set; } = "INFO"; public string Message { get; set; } = ""; }

public class OutageInfo { public int Id { get; set; } public DateTime Start { get; set; } public DateTime? End { get; set; } public double DurationSec { get; set; } public string Reason { get; set; } = ""; }

public class PrimaryDetail
{
    public bool InRecovery { get; set; }
    public string CurrentLsn { get; set; } = "-";
    public int MaxConnections { get; set; }
    public int ConnActive { get; set; }
    public int ConnIdle { get; set; }
    public int ConnIdleInTx { get; set; }
    public int ConnLockWait { get; set; }
    public double Tps { get; set; }
    public double CacheHitPct { get; set; }
    public long Deadlocks { get; set; }
    public long TempFiles { get; set; }
    public double WalRate { get; set; }
    public int WalFiles { get; set; }
    public long WalDirBytes { get; set; }
    public string ArchiveMode { get; set; } = "-";
    public long Archived { get; set; }
    public long ArchiveFailed { get; set; }
    public DateTime? LastArchived { get; set; }
    public List<ClientInfo> Clients { get; set; } = new();
    public List<QueryInfo> Queries { get; set; } = new();
    public List<SettingInfo> Settings { get; set; } = new();
}
public class ClientInfo { public string Addr { get; set; } = "-"; public string App { get; set; } = ""; public string State { get; set; } = "-"; public string Sync { get; set; } = "-"; public long LagBytes { get; set; } public double ReplayLagMs { get; set; } public DateTime? Since { get; set; } }
public class QueryInfo { public int Pid { get; set; } public string User { get; set; } = ""; public string Db { get; set; } = ""; public string App { get; set; } = ""; public string State { get; set; } = ""; public double Seconds { get; set; } public string Text { get; set; } = ""; }
public class SettingInfo { public string Name { get; set; } = ""; public string Value { get; set; } = ""; public string Unit { get; set; } = ""; }

// ======================= Logical replication monitor =======================
public class LogicalMonitor : BackgroundService
{
    private readonly ReplicationMonitor _main;
    private readonly string? _pubCs, _subCs;
    private readonly int _intervalSec;
    private readonly long _lagWarn;
    private readonly object _lock = new();
    private LogicalNode _pub = new() { Role = "Publisher" };
    private LogicalNode _sub = new() { Role = "Subscriber" };
    private readonly List<LogicalPoint> _hist = new();
    private string _status = "none", _reason = "Starting...";
    private DateTime _checkedAt = DateTime.Now;
    private string? _prevStatus;
    private readonly Dictionary<string, string> _prevStates = new();
    private readonly Dictionary<string, (long ins, long upd, long del, DateTime t)> _prevStats = new();
    private int _n = 0;

    public LogicalMonitor(IConfiguration cfg, ReplicationMonitor main)
    {
        _main = main;
        string? Get(string k) { var v = cfg.GetConnectionString(k); return string.IsNullOrWhiteSpace(v) ? null : v; }
        _pubCs = Get("LogicalPublisher") ?? Get("Primary");   // publisher defaults to the primary connection
        _subCs = Get("LogicalSubscriber");                    // optional
        _intervalSec = Math.Max(1, cfg.GetValue("Monitor:IntervalSeconds", 2));
        _lagWarn = cfg.GetValue("Monitor:LagWarnBytes", 16L * 1024 * 1024);
    }

    protected override async Task ExecuteAsync(CancellationToken ct)
    {
        while (!ct.IsCancellationRequested)
        {
            try { await PollOnce(); } catch (Exception ex) { _main.LogEvent("ERROR", "Logical monitor error: " + ex.Message); }
            await Task.Delay(TimeSpan.FromSeconds(_intervalSec), ct);
        }
    }

    private async Task PollOnce()
    {
        bool slow = (_n++ % 10 == 0);
        LogicalNode prevPub, prevSub;
        lock (_lock) { prevPub = _pub; prevSub = _sub; }
        var pub = await ReadNode("Publisher", _pubCs, prevPub, slow);
        var sub = await ReadNode("Subscriber", _subCs, prevSub, slow);
        var (status, reason) = Evaluate(pub, sub);
        lock (_lock)
        {
            _pub = pub; _sub = sub; _status = status; _reason = reason; _checkedAt = DateTime.Now;
            _hist.Add(new LogicalPoint
            {
                Time = _checkedAt.ToString("HH:mm:ss"),
                LagBytes = pub.Slots.Select(x => x.LagBytes).DefaultIfEmpty(0).Max(),
                ApplyRate = (sub.Configured ? sub : pub).TableStats.Sum(x => x.InsRate + x.UpdRate + x.DelRate),
                Workers = sub.Workers.Count(x => x.Pid > 0),
                Status = status
            });
            if (_hist.Count > 180) _hist.RemoveAt(0);
            DetectChanges(sub, status, reason);
        }
    }

    private void DetectChanges(LogicalNode sub, string status, string reason)
    {
        if (_prevStatus != status)
        {
            if (status == "working") _main.LogEvent("SUCCESS", "Logical replication is WORKING");
            else if (status == "syncing") _main.LogEvent("INFO", "Logical replication: tables are synchronising - " + reason);
            else if (status == "down") _main.LogEvent("ERROR", "Logical replication is NOT working - " + reason);
            else if (_prevStatus != null) _main.LogEvent("INFO", "Logical replication: " + reason);
            _prevStatus = status;
        }
        foreach (var t in sub.SubTables)
        {
            var key = t.Sub + "|" + t.Schema + "." + t.Table;
            if (_prevStates.TryGetValue(key, out var old) && old != t.State)
                _main.LogEvent(t.State == "r" ? "SUCCESS" : "INFO", $"Logical table {t.Schema}.{t.Table}: state {old} -> {t.State}");
            _prevStates[key] = t.State;
        }
    }

    private static (string, string) Evaluate(LogicalNode pub, LogicalNode sub)
    {
        if (!pub.Reachable) return ("down", "Publisher " + pub.Host + " is unreachable" + (pub.Error != null ? ": " + pub.Error : ""));
        bool anyPub = pub.Publications.Count > 0;
        bool anySub = sub.Configured && sub.Subs.Count > 0;
        if (!anyPub && !anySub && pub.Slots.Count == 0)
            return ("none", "No publication or logical slot found in the publisher database (" + pub.Database + ")");
        var reasons = new List<string>();
        if (pub.WalLevel != "logical") reasons.Add("wal_level is \"" + pub.WalLevel + "\" on the publisher (must be logical)");
        if (anyPub && pub.Slots.Count == 0) reasons.Add("publication exists but no subscriber has created a logical slot");
        foreach (var sl in pub.Slots) if (!sl.Active) reasons.Add($"logical slot \"{sl.Name}\" is inactive (subscriber not connected)");
        if (sub.Configured)
        {
            if (!sub.Reachable) reasons.Add("subscriber " + sub.Host + " is unreachable" + (sub.Error != null ? ": " + sub.Error : ""));
            else foreach (var sb in sub.Subs)
            {
                if (!sb.Enabled) reasons.Add($"subscription \"{sb.Name}\" is disabled");
                else if (!sub.Workers.Any(w => w.Sub == sb.Name && w.Pid > 0 && w.Table == "")) reasons.Add($"no apply worker running for subscription \"{sb.Name}\"");
            }
        }
        if (reasons.Count > 0) return ("down", string.Join("; ", reasons));
        bool syncing = sub.Configured && sub.SubTables.Any(t => t.State != "r");
        return (syncing ? "syncing" : "working", syncing ? "initial table synchronisation in progress" : "all logical slots active and tables ready");
    }

    private async Task<LogicalNode> ReadNode(string role, string? cs, LogicalNode prev, bool slow)
    {
        var n = new LogicalNode { Role = role, Configured = cs != null };
        if (cs == null) return n;
        try { var b = new NpgsqlConnectionStringBuilder(cs); n.Host = $"{b.Host}:{b.Port}"; n.Database = b.Database ?? "-"; }
        catch (Exception ex) { n.Error = "Invalid connection string: " + ex.Message; return n; }
        bool load = slow || !prev.Loaded;
        try
        {
            await using var con = new NpgsqlConnection(cs);
            await con.OpenAsync();
            n.Reachable = true;

            async Task Q(string sql, Func<NpgsqlDataReader, Task> read, string[]? names = null)
            {
                try
                {
                    await using var c = new NpgsqlCommand(sql, con);
                    if (names != null) c.Parameters.AddWithValue("names", names);
                    await using var r = await c.ExecuteReaderAsync();
                    await read(r);
                }
                catch { /* optional / version dependent - ignore */ }
            }
            async Task Opt(string table, string nameCol, string where, string[] cols, Action<string, string, string> set)
            {
                foreach (var col in cols)
                    await Q($"SELECT {nameCol}, {col}::text FROM {table} {where}", async r =>
                    { while (await r.ReadAsync()) set(r.GetString(0), col, r.IsDBNull(1) ? "" : r.GetString(1)); });
            }
            const string dbFilter = "WHERE subdbid = (SELECT oid FROM pg_database WHERE datname = current_database())";

            await Q("SELECT current_setting('server_version'), pg_is_in_recovery(), current_setting('wal_level')", async r =>
            { if (await r.ReadAsync()) { n.Version = r.GetString(0); n.InRecovery = r.GetBoolean(1); n.WalLevel = r.GetString(2); } });

            // ---- slow-changing definitions (publications, tables, settings) ----
            n.Loaded = true;
            if (load)
            {
                await Q("SELECT pubname, puballtables, pubinsert, pubupdate, pubdelete FROM pg_publication ORDER BY pubname", async r =>
                {
                    while (await r.ReadAsync())
                    {
                        var pp = new PubInfo { Name = r.GetString(0) };
                        pp.Params["all_tables"] = r.GetBoolean(1) ? "true" : "false";
                        pp.Params["insert"] = r.GetBoolean(2) ? "true" : "false";
                        pp.Params["update"] = r.GetBoolean(3) ? "true" : "false";
                        pp.Params["delete"] = r.GetBoolean(4) ? "true" : "false";
                        n.Publications.Add(pp);
                    }
                });
                await Opt("pg_publication", "pubname", "", new[] { "pubtruncate", "pubviaroot" }, (name, col, val) =>
                { var pp = n.Publications.FirstOrDefault(x => x.Name == name); if (pp != null) pp.Params[col.Replace("pub", "")] = val; });
                await Q("SELECT pubname, schemaname, tablename FROM pg_publication_tables ORDER BY 1,2,3 LIMIT 500", async r =>
                { while (await r.ReadAsync()) n.PubTables.Add(new PubTable { Pub = r.GetString(0), Schema = r.GetString(1), Table = r.GetString(2) }); });
                await Q("SELECT pubname, schemaname, tablename, COALESCE(array_to_string(attnames, ','), ''), COALESCE(rowfilter, '') FROM pg_publication_tables ORDER BY 1,2,3 LIMIT 500", async r =>
                {
                    var l = new List<PubTable>();
                    while (await r.ReadAsync()) l.Add(new PubTable { Pub = r.GetString(0), Schema = r.GetString(1), Table = r.GetString(2), Columns = r.GetString(3), RowFilter = r.GetString(4) });
                    if (l.Count > 0) n.PubTables = l;
                });
                await Q(@"SELECT name, setting, COALESCE(unit,'') FROM pg_settings WHERE name IN
                          ('wal_level','max_replication_slots','max_wal_senders','max_logical_replication_workers','max_sync_workers_per_subscription','max_worker_processes') ORDER BY name", async r =>
                { while (await r.ReadAsync()) n.Settings.Add(new SettingInfo { Name = r.GetString(0), Value = r.GetString(1), Unit = r.GetString(2) }); });
            }
            else { n.Publications = prev.Publications; n.PubTables = prev.PubTables; n.Settings = prev.Settings; }

            // ---- subscriptions ----
            await Q("SELECT subname, subenabled, COALESCE(subslotname,''), subsynccommit, COALESCE(array_to_string(subpublications, ','), '') FROM pg_subscription " + dbFilter + " ORDER BY subname", async r =>
            {
                while (await r.ReadAsync())
                    n.Subs.Add(new SubInfo { Name = r.GetString(0), Enabled = r.GetBoolean(1), Slot = r.GetString(2), SyncCommit = r.GetString(3), Publications = r.GetString(4) });
            });
            if (load)
                await Opt("pg_subscription", "subname", dbFilter, new[] { "subbinary", "substream", "subtwophasestate", "subdisableonerr", "suborigin", "subfailover" }, (name, col, val) =>
                { var sb = n.Subs.FirstOrDefault(x => x.Name == name); if (sb != null) sb.Params[col.Substring(3)] = val; });
            else
                foreach (var sb in n.Subs) { var old = prev.Subs.FirstOrDefault(x => x.Name == sb.Name); if (old != null) sb.Params = old.Params; }
            await Q("SELECT subname, apply_error_count, sync_error_count FROM pg_stat_subscription_stats", async r =>
            {
                while (await r.ReadAsync())
                {
                    var sb = n.Subs.FirstOrDefault(x => x.Name == r.GetString(0));
                    if (sb != null) { sb.ApplyErrors = r.GetInt64(1); sb.SyncErrors = r.GetInt64(2); }
                }
            });

            // ---- per-table sync state (subscriber) ----
            await Q(@"SELECT s.subname, n.nspname, c.relname, r.srsubstate::text, COALESCE(r.srsublsn::text,'-')
                      FROM pg_subscription_rel r JOIN pg_class c ON c.oid = r.srrelid JOIN pg_namespace n ON n.oid = c.relnamespace JOIN pg_subscription s ON s.oid = r.srsubid
                      WHERE s.subdbid = (SELECT oid FROM pg_database WHERE datname = current_database()) ORDER BY 1,2,3 LIMIT 500", async r =>
            { while (await r.ReadAsync()) n.SubTables.Add(new SubTable { Sub = r.GetString(0), Schema = r.GetString(1), Table = r.GetString(2), State = r.GetString(3), Lsn = r.GetString(4) }); });

            // ---- workers (subscriber) ----
            await Q(@"SELECT COALESCE(subname,''), COALESCE(pid,0), COALESCE(relid::regclass::text,''), COALESCE(received_lsn::text,'-'), COALESCE(latest_end_lsn::text,'-'),
                             COALESCE(EXTRACT(EPOCH FROM (now() - last_msg_receipt_time)) * 1000, -1)::float8
                      FROM pg_stat_subscription", async r =>
            { while (await r.ReadAsync()) n.Workers.Add(new LWorker { Sub = r.GetString(0), Pid = r.GetInt32(1), Table = r.GetString(2), ReceivedLsn = r.GetString(3), LatestEndLsn = r.GetString(4), MsgAgeMs = r.GetDouble(5) }); });

            // ---- logical slots + walsenders (publisher) ----
            await Q(@"SELECT slot_name, COALESCE(plugin,''), COALESCE(database,''), active, COALESCE(active_pid,0), COALESCE(restart_lsn::text,'-'), COALESCE(confirmed_flush_lsn::text,'-'),
                             COALESCE(pg_wal_lsn_diff(pg_current_wal_lsn(), restart_lsn),0)::bigint, COALESCE(pg_wal_lsn_diff(pg_current_wal_lsn(), confirmed_flush_lsn),0)::bigint
                      FROM pg_replication_slots WHERE slot_type = 'logical' ORDER BY slot_name", async r =>
            {
                while (await r.ReadAsync())
                    n.Slots.Add(new LSlot { Name = r.GetString(0), Plugin = r.GetString(1), Database = r.GetString(2), Active = r.GetBoolean(3), ActivePid = r.GetInt32(4),
                        RestartLsn = r.GetString(5), ConfirmedLsn = r.GetString(6), RetainedBytes = r.GetInt64(7), LagBytes = r.GetInt64(8) });
            });
            if (load)
                await Q("SELECT slot_name, COALESCE(wal_status,'') FROM pg_replication_slots WHERE slot_type = 'logical'", async r =>
                { while (await r.ReadAsync()) { var nm = r.GetString(0); var sl = n.Slots.FirstOrDefault(x => x.Name == nm); if (sl != null) sl.WalStatus = r.GetString(1); } });
            else
                foreach (var sl in n.Slots) { var old = prev.Slots.FirstOrDefault(x => x.Name == sl.Name); if (old != null) sl.WalStatus = old.WalStatus; }
            await Q(@"SELECT COALESCE(r.application_name,''), COALESCE(r.client_addr::text,'-'), COALESCE(r.state,'-'), COALESCE(r.sync_state,'-'), COALESCE(r.sent_lsn::text,'-'), COALESCE(r.flush_lsn::text,'-'), COALESCE(r.replay_lsn::text,'-'),
                             COALESCE(pg_wal_lsn_diff(pg_current_wal_lsn(), r.replay_lsn),0)::bigint, COALESCE(EXTRACT(EPOCH FROM r.replay_lag)*1000,0)::float8, s.slot_name
                      FROM pg_stat_replication r JOIN pg_replication_slots s ON s.active_pid = r.pid WHERE s.slot_type = 'logical' ORDER BY 1", async r =>
            {
                while (await r.ReadAsync())
                    n.Senders.Add(new LSender { App = r.GetString(0), Addr = r.GetString(1), State = r.GetString(2), Sync = r.GetString(3), SentLsn = r.GetString(4), FlushLsn = r.GetString(5),
                        ReplayLsn = r.GetString(6), LagBytes = r.GetInt64(7), ReplayLagMs = r.GetDouble(8), Slot = r.GetString(9) });
            });

            // ---- live per-table counters -> changes per second ----
            var tblNames = n.PubTables.Select(x => x.Schema + "." + x.Table).Concat(n.SubTables.Select(x => x.Schema + "." + x.Table)).Distinct().Take(500).ToArray();
            if (tblNames.Length > 0)
            {
                var now = DateTime.Now;
                await Q(@"SELECT schemaname || '.' || relname, COALESCE(n_live_tup,0), COALESCE(n_tup_ins,0), COALESCE(n_tup_upd,0), COALESCE(n_tup_del,0), pg_total_relation_size(relid)
                          FROM pg_stat_user_tables WHERE schemaname || '.' || relname = ANY(@names) ORDER BY 1", async r =>
                {
                    while (await r.ReadAsync())
                    {
                        var ts = new TableStat { Name = r.GetString(0), LiveRows = r.GetInt64(1), Ins = r.GetInt64(2), Upd = r.GetInt64(3), Del = r.GetInt64(4), SizeBytes = r.GetInt64(5) };
                        var key = role + "|" + ts.Name;
                        if (_prevStats.TryGetValue(key, out var pv))
                        {
                            var dt = (now - pv.t).TotalSeconds;
                            if (dt > 0.5) { ts.InsRate = Math.Max(0, (ts.Ins - pv.ins) / dt); ts.UpdRate = Math.Max(0, (ts.Upd - pv.upd) / dt); ts.DelRate = Math.Max(0, (ts.Del - pv.del) / dt); }
                        }
                        _prevStats[key] = (ts.Ins, ts.Upd, ts.Del, now);
                        n.TableStats.Add(ts);
                    }
                }, tblNames);
            }
        }
        catch (Exception ex) { n.Error = ex.Message; }
        return n;
    }

    public object GetState()
    {
        lock (_lock)
            return new { checkedAt = _checkedAt, status = _status, reason = _reason, intervalSeconds = _intervalSec, lagWarnBytes = _lagWarn, publisher = _pub, subscriber = _sub, history = _hist.ToList() };
    }

    // exact row count on both sides (user-triggered, only for known tables)
    public async Task<object> CountRows(string schema, string table)
    {
        LogicalNode pub, sub;
        lock (_lock) { pub = _pub; sub = _sub; }
        bool known = pub.PubTables.Any(x => x.Schema == schema && x.Table == table) || sub.SubTables.Any(x => x.Schema == schema && x.Table == table);
        if (!known) return new { error = "Unknown table", publisher = (object?)null, subscriber = (object?)null };

        async Task<object> One(string? cs)
        {
            if (cs == null) return new { ok = false, count = 0L, ms = 0L, error = (string?)"not configured" };
            var sw = System.Diagnostics.Stopwatch.StartNew();
            try
            {
                var qb = new NpgsqlCommandBuilder();
                await using var c = new NpgsqlConnection(cs);
                await c.OpenAsync();
                await using var cmd = new NpgsqlCommand($"SELECT count(*) FROM {qb.QuoteIdentifier(schema)}.{qb.QuoteIdentifier(table)}", c) { CommandTimeout = 60 };
                var v = (long)(await cmd.ExecuteScalarAsync() ?? 0L);
                return new { ok = true, count = v, ms = sw.ElapsedMilliseconds, error = (string?)null };
            }
            catch (Exception ex) { return new { ok = false, count = 0L, ms = sw.ElapsedMilliseconds, error = (string?)ex.Message }; }
        }
        return new { error = (string?)null, publisher = await One(_pubCs), subscriber = await One(_subCs) };
    }
}

public class LogicalNode
{
    public string Role { get; set; } = "";
    public bool Configured { get; set; }
    public bool Loaded { get; set; }
    public string Host { get; set; } = "-";
    public string Database { get; set; } = "-";
    public bool Reachable { get; set; }
    public string? Error { get; set; }
    public string Version { get; set; } = "-";
    public bool InRecovery { get; set; }
    public string WalLevel { get; set; } = "-";
    public List<PubInfo> Publications { get; set; } = new();
    public List<PubTable> PubTables { get; set; } = new();
    public List<LSlot> Slots { get; set; } = new();
    public List<LSender> Senders { get; set; } = new();
    public List<SubInfo> Subs { get; set; } = new();
    public List<SubTable> SubTables { get; set; } = new();
    public List<LWorker> Workers { get; set; } = new();
    public List<TableStat> TableStats { get; set; } = new();
    public List<SettingInfo> Settings { get; set; } = new();
}
public class PubInfo { public string Name { get; set; } = ""; public Dictionary<string, string> Params { get; set; } = new(); }
public class PubTable { public string Pub { get; set; } = ""; public string Schema { get; set; } = ""; public string Table { get; set; } = ""; public string Columns { get; set; } = ""; public string RowFilter { get; set; } = ""; }
public class LSlot { public string Name { get; set; } = ""; public string Plugin { get; set; } = ""; public string Database { get; set; } = ""; public bool Active { get; set; } public int ActivePid { get; set; } public string RestartLsn { get; set; } = "-"; public string ConfirmedLsn { get; set; } = "-"; public long RetainedBytes { get; set; } public long LagBytes { get; set; } public string WalStatus { get; set; } = ""; }
public class LSender { public string App { get; set; } = ""; public string Addr { get; set; } = "-"; public string State { get; set; } = "-"; public string Sync { get; set; } = "-"; public string SentLsn { get; set; } = "-"; public string FlushLsn { get; set; } = "-"; public string ReplayLsn { get; set; } = "-"; public long LagBytes { get; set; } public double ReplayLagMs { get; set; } public string Slot { get; set; } = ""; }
public class SubInfo { public string Name { get; set; } = ""; public bool Enabled { get; set; } public string Slot { get; set; } = ""; public string SyncCommit { get; set; } = ""; public string Publications { get; set; } = ""; public Dictionary<string, string> Params { get; set; } = new(); public long ApplyErrors { get; set; } public long SyncErrors { get; set; } }
public class SubTable { public string Sub { get; set; } = ""; public string Schema { get; set; } = ""; public string Table { get; set; } = ""; public string State { get; set; } = ""; public string Lsn { get; set; } = "-"; }
public class LWorker { public string Sub { get; set; } = ""; public int Pid { get; set; } public string Table { get; set; } = ""; public string ReceivedLsn { get; set; } = "-"; public string LatestEndLsn { get; set; } = "-"; public double MsgAgeMs { get; set; } }
public class TableStat { public string Name { get; set; } = ""; public long LiveRows { get; set; } public long Ins { get; set; } public long Upd { get; set; } public long Del { get; set; } public double InsRate { get; set; } public double UpdRate { get; set; } public double DelRate { get; set; } public long SizeBytes { get; set; } }
public class LogicalPoint { public string Time { get; set; } = ""; public long LagBytes { get; set; } public double ApplyRate { get; set; } public int Workers { get; set; } public string Status { get; set; } = ""; }
