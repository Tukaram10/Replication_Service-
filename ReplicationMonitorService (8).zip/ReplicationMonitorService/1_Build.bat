@echo off
cd /d "%~dp0"
echo "%~dp0" | find /i "Program Files" >nul
if not errorlevel 1 (
  echo.
  echo This folder is inside "Program Files", which Windows protects - the build cannot write there.
  echo Move the whole ReplicationMonitorService folder to e.g.  C:\Services_Tuka\ReplicationMonitorService
  echo and run 1_Build.bat again.
  pause & exit /b 1
)
where dotnet >nul 2>&1
if errorlevel 1 (
  echo .NET SDK not found. Install it from https://dotnet.microsoft.com/download
  pause & exit /b 1
)
set SVER=
for /f "delims=" %%v in ('powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Bump_Version.ps1"') do set SVER=%%v
if not defined SVER set SVER=1.0.0
echo Version: %SVER%  (service + portal)
echo Building ReplicationMonitor (self-contained, win-x64)...
dotnet publish ReplicationMonitor.csproj -c Release -r win-x64 --self-contained true -p:Version=%SVER% -o "%~dp0publish"
if errorlevel 1 (
  echo.
  echo BUILD FAILED
  pause & exit /b 1
)
echo.
echo BUILD OK  version %SVER%  ->  %~dp0publish
echo Next: edit publish\appsettings.json (Primary / Standby connection strings),
echo       then run 2_Install_Service.bat as Administrator.
pause
